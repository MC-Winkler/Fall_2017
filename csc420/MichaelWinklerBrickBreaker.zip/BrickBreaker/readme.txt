Name: Michael Winkler

How to Play: Just hit the unity play button and the game will begin automatically. The ball will be
launched at one of five possible starting angles. Click the button in the top right corner to restart
the game. 

Credits: Textures were pulled from the website linked in the make a maze assignment: 
http://www.tutorialsforblender3d.com/Textures/Textures_index.html
The skybox is free on the unity store: 
https://www.assetstore.unity3d.com/en/#!/content/3392

Features: Basic brick breaker functionality, with a ball that bounces off a paddle and breaks
bricks. The paddle is moved by the mouse. There are three levels, and with each level your paddle 
gets smaller. If you beat all three levels, you beat the game. The ball goes slightly faster with each
brick you break, though the speed resets between levels, as do your lives. You get three lives before you 
lose. The reset button in the top right corner restarts the game to the beginning of the first level. 

Known Bugs: The bricks aren't exactly centered, and I'm not sure why.